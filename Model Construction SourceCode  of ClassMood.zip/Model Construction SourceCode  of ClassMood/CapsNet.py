import torch
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision import datasets
import torch.nn as nn
import torchvision.models as models
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
from tqdm import tqdm
import torch.nn.functional as F
import numpy as np
import os

import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvLayer(nn.Module):
    def __init__(self):
        super(ConvLayer, self).__init__()
        self.conv = nn.Conv2d(3, 64, kernel_size=9, stride=1, padding=0)

    def forward(self, x):
        return F.relu(self.conv(x))

class PrimaryCapsules(nn.Module):
    def __init__(self, num_capsules=8, in_channels=64, out_dim=8, kernel_size=9, stride=4):
        super(PrimaryCapsules, self).__init__()
        self.num_capsules = num_capsules
        self.out_dim = out_dim
        self.capsules = nn.Conv2d(in_channels, num_capsules * out_dim,
                                  kernel_size=kernel_size, stride=stride)

    def forward(self, x):
        batch_size = x.size(0)
        out = self.capsules(x)
        out = out.view(batch_size, self.num_capsules, self.out_dim, -1)
        out = out.permute(0, 3, 1, 2).contiguous()
        out = out.view(batch_size, -1, self.out_dim)
        return self.squash(out)

    def squash(self, x, dim=-1):
        squared_norm = (x ** 2).sum(dim=dim, keepdim=True)
        scale = squared_norm / (1.0 + squared_norm)
        return scale * x / torch.sqrt(squared_norm + 1e-8)

class DigitCapsules(nn.Module):
    def __init__(self, num_capsules=7, num_routes=1152, in_dim=8, out_dim=16, num_iterations=3):
        super(DigitCapsules, self).__init__()
        self.num_capsules = num_capsules
        self.num_routes = num_routes
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.num_iterations = num_iterations
        self.route_weights = nn.Parameter(torch.randn(1, num_routes, num_capsules, out_dim, in_dim))

    def forward(self, x):
        batch_size = x.size(0)
        capsule_norms = torch.norm(x, dim=-1)
        topk_vals, topk_idx = torch.topk(capsule_norms, self.num_routes, dim=1)
        batch_indices = torch.arange(batch_size).unsqueeze(1).to(x.device)
        x = x[batch_indices, topk_idx]
        x = x.unsqueeze(2).unsqueeze(4)
        x = x.repeat(1, 1, self.num_capsules, 1, 1)
        weights = self.route_weights.repeat(batch_size, 1, 1, 1, 1)
        u_hat = torch.matmul(weights, x).squeeze(-1)
        b_ij = torch.zeros(batch_size, self.num_routes, self.num_capsules, 1, device=x.device)
        for iteration in range(self.num_iterations):
            c_ij = F.softmax(b_ij, dim=2)
            s_j = (c_ij * u_hat).sum(dim=1, keepdim=True)
            v_j = self.squash(s_j, dim=-1)
            if iteration < self.num_iterations - 1:
                b_ij = b_ij + (u_hat * v_j).sum(dim=-1, keepdim=True)
        return v_j.squeeze(1)

    def squash(self, x, dim=-1):
        squared_norm = (x ** 2).sum(dim=dim, keepdim=True)
        scale = squared_norm / (1.0 + squared_norm)
        return scale * x / torch.sqrt(squared_norm + 1e-8)

class CapsuleNetwork(nn.Module):
    def __init__(self):
        super(CapsuleNetwork, self).__init__()
        self.conv1 = ConvLayer()
        self.primary_caps = PrimaryCapsules()
        self.digit_caps = DigitCapsules(num_capsules=7, num_routes=1152, in_dim=8, out_dim=16)
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = self.conv1(x)
        x = self.primary_caps(x)
        x = self.digit_caps(x)
        x = x.norm(dim=-1)
        return x

def create_model():
    return CapsuleNetwork()

def train_model(model, train_loader, test_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=120, patience=5):
    best_test_acc = 0.0
    best_model = None
    model.to(device)
    torch.save(model.state_dict(), 'best_model.pth')
    plt.ioff()
    epochs_without_improvement = 0
    for epoch in range(num_epochs):
        model.train()
        train_loss, correct, total = 0.0, 0, 0
        for images, labels in tqdm(train_loader, desc="Training"):
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        model.eval()
        test_loss, test_correct, test_total = 0.0, 0, 0
        test_labels, test_preds = [], []
        with torch.no_grad():
            for images, labels in test_loader:
                images = images.to(device, non_blocking=True)
                labels = labels.to(device, non_blocking=True)
                outputs = model(images)
                loss = criterion(outputs, labels)
                test_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                test_total += labels.size(0)
                test_correct += (predicted == labels).sum().item()
                test_labels.extend(labels.cpu().numpy())
                test_preds.extend(predicted.cpu().numpy())
        test_acc = 100 * test_correct / test_total
        scheduler.step(test_acc)

        if test_acc > best_test_acc:
            best_test_acc = test_acc
            best_model = model.state_dict()
            torch.save(best_model, 'best_model_CapsNet.pth')

        val_accuracy_current = evaluate_model_on_val(model, val_loader, device)
        if val_accuracy_current <= val_accuracy_best:
            epochs_without_improvement += 1
        else:
            epochs_without_improvement = 0
        if epochs_without_improvement >= patience:
            print(f"Early stopping triggered at epoch {epoch + 1}")
            break

def evaluate_model_on_val(model, val_loader, device):
    model.to(device).eval()
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    return 100 * correct / total

def main():
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    train_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.Grayscale(num_output_channels=3),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.RandomResizedCrop(256, scale=(0.9, 1.0)),
        transforms.ColorJitter(brightness=0.1, contrast=0.1),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])

    val_test_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])

    train_dataset = datasets.ImageFolder('./train_dataset',transform=train_transform)
    test_dataset = datasets.ImageFolder('./test_dataset',transform=val_test_transform)
    val_dataset = datasets.ImageFolder('./val_dataset',transform=val_test_transform)

    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

    model = create_model()
    samples_per_class = [4384, 307, 2540, 6367, 2367, 454, 1785]
    total = sum(samples_per_class)
    class_weights = [total / c for c in samples_per_class]
    class_weights = torch.FloatTensor(class_weights).to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=5)

    train_model(model, train_loader, test_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=120)
    evaluate_model_on_val(model, val_loader, device)

if __name__ == "__main__":
    main()

