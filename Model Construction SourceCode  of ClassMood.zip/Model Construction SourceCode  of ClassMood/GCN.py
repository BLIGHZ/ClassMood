import torch
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision import datasets
import torch.nn as nn
import torchvision.models as models
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import torch.nn.functional as F
import numpy as np
import os
from tqdm import tqdm

class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features):
        super(GraphConvolution, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, X, A_norm):
        out = self.linear(X)
        out = torch.matmul(A_norm, out)
        return F.relu(out)

class GNN_FER(nn.Module):
    def __init__(self, num_classes=7, num_patches=64, patch_dim=64, gcn_hidden=128):
        super(GNN_FER, self).__init__()
        self.num_patches = num_patches
        self.patch_dim = patch_dim
        self.unfold = nn.Unfold(kernel_size=32, stride=32)
        self.fc_patch = nn.Linear(3 * 32 * 32, patch_dim)
        grid_size = 8
        centers = []
        for i in range(grid_size):
            for j in range(grid_size):
                centers.append([i, j])
        centers = np.array(centers)
        centers = centers / (grid_size - 1)
        dists = np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=2)
        sigma = 0.5
        A = np.exp(- (dists ** 2) / (2 * sigma * sigma))
        A = torch.tensor(A, dtype=torch.float32)
        D = torch.diag(torch.sum(A, dim=1))
        D_inv_sqrt = torch.diag(1.0 / torch.sqrt(torch.sum(A, dim=1) + 1e-6))
        A_norm = D_inv_sqrt @ A @ D_inv_sqrt
        self.register_buffer('A_norm', A_norm)
        self.gcn1 = GraphConvolution(patch_dim, gcn_hidden)
        self.gcn2 = GraphConvolution(gcn_hidden, gcn_hidden)
        self.classifier = nn.Linear(gcn_hidden, num_classes)

    def forward(self, x):
        B = x.size(0)
        patches = self.unfold(x)
        patches = patches.transpose(1, 2)
        patch_features = self.fc_patch(patches)
        out = self.gcn1(patch_features, self.A_norm)
        out = self.gcn2(out, self.A_norm)
        out = out.mean(dim=1)
        logits = self.classifier(out)
        return logits

def create_model():
    model = GNN_FER(num_classes=7)
    return model

def train_model(model, train_loader, test_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=120, patience=5):
    best_test_acc = 0.0
    best_model = None
    model.to(device)
    torch.save(model.state_dict(), 'best_model.pth')
    epochs_without_improvement = 0

    for epoch in range(num_epochs):
        model.train()
        train_loss, correct, total = 0.0, 0, 0

        for images, labels in tqdm(train_loader, desc="Training"):
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        model.eval()
        test_loss, test_correct, test_total = 0.0, 0, 0
        test_labels, test_preds = [], []
        with torch.no_grad():
            for images, labels in test_loader:
                images = images.to(device, non_blocking=True)
                labels = labels.to(device, non_blocking=True)
                outputs = model(images)
                loss = criterion(outputs, labels)
                test_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                test_total += labels.size(0)
                test_correct += (predicted == labels).sum().item()
                test_labels.extend(labels.cpu().numpy())
                test_preds.extend(predicted.cpu().numpy())
        test_acc = 100 * test_correct / test_total
        scheduler.step(test_acc)
        if test_acc > best_test_acc:
            best_test_acc = test_acc
            best_model = model.state_dict()
            torch.save(best_model, 'best_model_GCN.pth')

        val_accuracy_current = evaluate_model_on_val(model, val_loader, device)
        if val_accuracy_current <= val_accuracy_best:
            epochs_without_improvement += 1
        else:
            epochs_without_improvement = 0
        if epochs_without_improvement >= patience:
            print(f"Early stopping triggered at epoch {epoch + 1}")
            break

def evaluate_model_on_val(model, val_loader, device):
    model.to(device).eval()
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    return 100 * correct / total

def main():
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    train_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.Grayscale(num_output_channels=3),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.RandomResizedCrop(256, scale=(0.9, 1.0)),
        transforms.ColorJitter(brightness=0.1, contrast=0.1),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])

    val_test_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])

    train_dataset = datasets.ImageFolder('./train_dataset', transform=train_transform)
    test_dataset = datasets.ImageFolder('./test_dataset', transform=val_test_transform)
    val_dataset = datasets.ImageFolder('./val_dataset', transform=val_test_transform)

    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

    model = create_model()
    samples_per_class = [4384, 307, 2540, 6367, 2367, 454, 1785]
    total = sum(samples_per_class)
    class_weights = [total / c for c in samples_per_class]
    class_weights = torch.FloatTensor(class_weights).to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=5)

    train_model(model, train_loader, test_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=120)
    evaluate_model_on_val(model, val_loader, device)


if __name__ == "__main__":
    main()
