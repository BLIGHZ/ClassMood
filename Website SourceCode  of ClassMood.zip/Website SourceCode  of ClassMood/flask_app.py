from flask import Flask, request, jsonify, render_template
import torch
import torch.nn as nn
import torchvision.models as models
from PIL import Image
import io
import torchvision.transforms as transforms


# Initialize Flask app
app = Flask(__name__)

# Seven emotion categories (aligned with model output)
class_names = [
    'disgust',
    'fear',
    'happiness',
    'others',
    'repression',
    'sadness',
    'surprise'
]

# Mapping from 7 fine-grained classes to 3 macro emotion types
emotion_map = {
    'happiness': 'Positive',
    'surprise': 'Positive',
    'disgust': 'Negative',
    'fear': 'Negative',
    'sadness': 'Negative',
    'repression': 'Others',
    'others': 'Others'
}


# --------------------------
# CBAM Modules
# --------------------------
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(ChannelAttention, self).__init__()
        self.fc1 = nn.Conv2d(in_channels, in_channels // reduction, 1, bias=False)
        self.fc2 = nn.Conv2d(in_channels // reduction, in_channels, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_pool = torch.mean(x, dim=[2, 3], keepdim=True)
        max_pool, _ = torch.max(x, dim=2, keepdim=True)
        max_pool, _ = torch.max(max_pool, dim=3, keepdim=True)
        avg_out = self.fc2(self.fc1(avg_pool))
        max_out = self.fc2(self.fc1(max_pool))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_pool = torch.mean(x, dim=1, keepdim=True)
        max_pool, _ = torch.max(x, dim=1, keepdim=True)
        x_cat = torch.cat([avg_pool, max_pool], dim=1)
        x_out = self.conv(x_cat)
        return self.sigmoid(x_out)


class CBAM(nn.Module):
    def __init__(self, in_channels, reduction=16, kernel_size=7):
        super(CBAM, self).__init__()
        self.channel_attention = ChannelAttention(in_channels, reduction)
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        x = x * self.channel_attention(x)
        x = x * self.spatial_attention(x)
        return x


# --------------------------
# Model definition (ResNet18 + CBAM)
# --------------------------
def create_model():
    model = models.resnet18(pretrained=True)

    # Freeze early layers
    for param in model.parameters():
        param.requires_grad = False

    # Trainable layers
    for param in model.layer3.parameters():
        param.requires_grad = True
    for param in model.layer4.parameters():
        param.requires_grad = True

    # Insert CBAM blocks
    model.layer3[0] = nn.Sequential(model.layer3[0], CBAM(256))
    model.layer4[0] = nn.Sequential(model.layer4[0], CBAM(512))

    # Classification head
    model.fc = nn.Sequential(
        nn.Dropout(0.5),
        nn.Linear(model.fc.in_features, 7)
    )

    return model


# --------------------------
# Load trained model
# --------------------------
model = create_model()
model.load_state_dict(torch.load(
    '/best_model.pth',
    map_location='cpu'
))
model.eval()


# --------------------------
# Image preprocessing
# --------------------------
preprocess = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.Grayscale(num_output_channels=3),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])


# --------------------------
# Prediction function
# --------------------------
def predict(image):
    image = preprocess(image).unsqueeze(0)
    with torch.no_grad():
        outputs = model(image)
        _, predicted = torch.max(outputs, 1)
    original_emotion = class_names[predicted.item()]
    final_emotion = emotion_map[original_emotion]
    return final_emotion


# --------------------------
# Flask routes
# --------------------------
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict_route():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Empty filename'}), 400

    try:
        image = Image.open(io.BytesIO(file.read()))
        predicted_class = predict(image)
        return render_template('pre_result.html', predicted_class=predicted_class), 200
    except Exception as e:
        return jsonify({'error': f"Error during prediction: {str(e)}"}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
